function Loading() {
    return ( 

        <div>
            Looding...
        </div>
     );
}

export default Loading;