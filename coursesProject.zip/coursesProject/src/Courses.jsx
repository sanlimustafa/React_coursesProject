import Course from "./Course";

function Courses({courses, removeCourse}) {
    return ( 

        <div className="courseMainDiv">
            <div>
                <h1>Kurslarım</h1>
            </div>
            <div className="cardDiv">
                {
                    courses.map((course) => {
                        return(
                           // <Course course={course} /> bunun yerine alltaki kullanılabilir.
                           // probs yerine objeyi direk geçebiliriz.
                           <Course key={course.id} {...course} removeOneCourse={removeCourse} />
                        )
                    })
                }
            </div>
        </div>
     );
}

export default Courses ;